const { sql, poolPromise } = require('../db');
const admin = require('../config/firebaseAdminConfig');

// Función para obtener el grupo de usuario por UID de Firebase
const getUserRole = async (req, res) => {
  const { uid } = req.params;
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('firebase_uid', sql.NVarChar, uid)
      .query('SELECT rol_id FROM Usuario WHERE FirebaseUid = @firebase_uid');

    if (result.recordset.length > 0) {
      res.json({ rol: result.recordset[0].rol_id });
    } else {
      res.status(404).json({ error: 'Usuario no encontrado' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};

// Función para obtener los datos de usuario por UID de Firebase
const getUserByUID = async (req, res) => {
  const { uid } = req.params;
  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('firebase_uid', sql.NVarChar, uid)
      .query('SELECT * FROM Usuario WHERE FirebaseUid = @firebase_uid');

    if (result.recordset.length > 0) {
      res.json(result.recordset[0]);
    } else {
      res.status(404).json({ error: "Usuario no encontrado" });
    }
  } catch (error) {
    console.error("Error al obtener usuario por UID:", error);
    res.status(500).send('Error del servidor');
  }
};


// Función para capitalizar nombres
const capitalize = (str) => str?.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());

// Crear usuario nuevo
const createUser = async (req, res) => {
  const {
    uid, nombre, segundoNombre, apellido, segundoApellido,
    email, cedulaRUC, telefono, ciudad, tipoContribuyente,
    username, rol_id
  } = req.body;

  try {
    const pool = await poolPromise;

    const exists = await pool.request()
      .input('correo', sql.NVarChar, email)
      .query('SELECT 1 FROM Usuario WHERE Correo = @correo');

    if (exists.recordset.length > 0) {
      return res.status(400).json({ error: 'El correo ya existe en la base de datos' });
    }

    await pool.request()
      .input('FirebaseUid', sql.NVarChar, uid)
      .input('Nombre', sql.NVarChar, capitalize(nombre))
      .input('SegundoNombre', sql.NVarChar, capitalize(segundoNombre))
      .input('Apellido', sql.NVarChar, capitalize(apellido))
      .input('SegundoApellido', sql.NVarChar, capitalize(segundoApellido))
      .input('Correo', sql.NVarChar, email)
      .input('CedulaRUC', sql.NVarChar, cedulaRUC)
      .input('Telefono', sql.NVarChar, telefono)
      .input('Ciudad', sql.NVarChar, ciudad)
      .input('TipoContribuyente', sql.NVarChar, tipoContribuyente)
      .input('Username', sql.NVarChar, username)
      .input('Rol_id', sql.Int, rol_id)
      .query(`
        INSERT INTO Usuario (
          FirebaseUid, Nombre, SegundoNombre, Apellido, SegundoApellido,
          Correo, CedulaRUC, Telefono, Ciudad, TipoContribuyente,
          Username, Rol_id, FechaRegistro
        ) VALUES (
          @FirebaseUid, @Nombre, @SegundoNombre, @Apellido, @SegundoApellido,
          @Correo, @CedulaRUC, @Telefono, @Ciudad, @TipoContribuyente,
          @Username, @Rol_id, GETDATE()
        )`);

    res.status(201).json({ message: "Usuario registrado en la base de datos" });
  } catch (error) {
    console.error("Error al guardar en la base:", error);
    res.status(500).json({ error: 'Error del servidor' });
  }
};


// Autenticación
const authenticateUser = async (req, res) => {
  const { username } = req.body;

  try {
    const pool = await poolPromise;
    const result = await pool.request()
      .input('username', sql.NVarChar, username)
      .query('SELECT * FROM Usuario WHERE Username = @username');

    if (result.recordset.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const user = result.recordset[0];
    await admin.auth().getUserByEmail(user.Correo);

    res.json({
      email: user.Correo,
      uid: user.FirebaseUid,
      rol_id: user.Rol_id,
      nombre: user.Nombre,
      username: user.Username
    });
  } catch (error) {
    console.error("Error en autenticación:", error);
    res.status(500).json({ error: 'Error del servidor' });
  }
};

// Restablecer contraseña
const resetPassword = async (req, res) => {
  const { email } = req.body;
  try {
    await admin.auth().generatePasswordResetLink(email);
    res.json({ message: 'Enlace enviado' });
  } catch (error) {
    res.status(500).json({ error: 'Error al enviar enlace de restablecimiento' });
  }
};

// Obtener todos los usuarios
const getUsers = async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT * FROM Usuario
    `);
    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};

// Actualizar usuario
const updateUser = async (req, res) => {
  const { id } = req.params;
  const {
    nombre, segundoNombre, apellido, segundoApellido,
    email, telefono, ciudad, tipoContribuyente, rol_id
  } = req.body;

  try {
    const pool = await poolPromise;

    await pool.request()
      .input('id', sql.Int, id)
      .input('Nombre', sql.NVarChar, capitalize(nombre))
      .input('SegundoNombre', sql.NVarChar, capitalize(segundoNombre))
      .input('Apellido', sql.NVarChar, capitalize(apellido))
      .input('SegundoApellido', sql.NVarChar, capitalize(segundoApellido))
      .input('Correo', sql.NVarChar, email)
      .input('Telefono', sql.NVarChar, telefono)
      .input('Ciudad', sql.NVarChar, ciudad)
      .input('TipoContribuyente', sql.NVarChar, tipoContribuyente)
      .input('Rol_id', sql.Int, rol_id)
      .query(`
        UPDATE Usuario SET
          Nombre = @Nombre, SegundoNombre = @SegundoNombre,
          Apellido = @Apellido, SegundoApellido = @SegundoApellido,
          Correo = @Correo, Telefono = @Telefono,
          Ciudad = @Ciudad, TipoContribuyente = @TipoContribuyente,
          Rol_id = @Rol_id
        WHERE id = @id
      `);

    res.json({ message: 'Usuario actualizado correctamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};

// Eliminar usuario
const deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    const pool = await poolPromise;
    const user = await pool.request()
      .input('id', sql.Int, id)
      .query('SELECT FirebaseUid FROM Usuario WHERE id = @id');

    if (user.recordset.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    const firebaseUid = user.recordset[0].FirebaseUid;

    await admin.auth().deleteUser(firebaseUid);
    await pool.request()
      .input('id', sql.Int, id)
      .query('DELETE FROM Usuario WHERE id = @id');

    res.json({ message: 'Usuario eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ error: 'Error del servidor' });
  }
};

const getDashboardAccess = async (req, res) => {
  const { rol } = req;

  let redirect;
  if (rol === 1) redirect = "/dashboard-admin";
  else if (rol === 2) redirect = "/dashboard-editor";
  else if (rol === 3) redirect = "/dashboard-usuario";
  else return res.status(403).json({ error: "Rol inválido" });

  res.json({ rol, redirect });
};


module.exports = {
  getUserRole,
  createUser,
  authenticateUser,
  resetPassword,
  getUsers,
  getUserByUID,
  updateUser,
  deleteUser,
  getDashboardAccess

};
