import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const VerUsuario = () => {
  const { id } = useParams();
  const [usuario, setUsuario] = useState(null);

  useEffect(() => {
    const fetchUsuario = async () => {
      try {
        const response = await fetch(`http://localhost:3001/api/users/${id}`);
        const data = await response.json();
        setUsuario(data);
      } catch (error) {
        console.error("Error al obtener usuario:", error);
      }
    };

    fetchUsuario();
  }, [id]);

  if (!usuario) return <p>Cargando usuario...</p>;

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white shadow-md rounded-xl mt-10">
      <h2 className="text-3xl font-bold text-center text-green-800 mb-6">
        Detalles del Usuario
      </h2>
      <div className="space-y-3">
        <p><strong>Nombre:</strong> {usuario.nombre} {usuario.segundoNombre}</p>
        <p><strong>Apellido:</strong> {usuario.apellido} {usuario.segundoApellido}</p>
        <p><strong>Cédula/RUC:</strong> {usuario.cedulaRUC}</p>
        <p><strong>Correo:</strong> {usuario.correo}</p>
        <p><strong>Teléfono:</strong> {usuario.telefono}</p>
        <p><strong>Ciudad:</strong> {usuario.ciudad}</p>
        <p><strong>Tipo Contribuyente:</strong> {usuario.tipoContribuyente}</p>
        <p><strong>Nombre de Usuario:</strong> {usuario.username}</p>
        <p><strong>Rol:</strong> {usuario.rol_id}</p>
        <p><strong>Registrado el:</strong> {new Date(usuario.fechaRegistro).toLocaleString()}</p>
      </div>
      <div className="mt-6 text-center">
        <Link to="/admin/usuarios" className="text-blue-600 hover:underline">Volver</Link>
      </div>
    </div>
  );
};

export default VerUsuario;
