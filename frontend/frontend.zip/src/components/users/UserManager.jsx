import { Routes, Route } from "react-router-dom";
import CrearUsuario from "./CrearUsuario";
import VerUsuario from "./VerUsuario";
import EditarUsuario from "./EditarUsuario";
import EliminarUsuario from "./EliminarUsuario";

const UserManager = ({ onlyView = false }) => {
  return (
    <Routes>
      {!onlyView && <Route path="crear" element={<CrearUsuario />} />}
      <Route path="ver/:id" element={<VerUsuario />} />
      {!onlyView && <Route path="editar/:uid" element={<EditarUsuario />} />}
      {!onlyView && <Route path="eliminar/:id" element={<EliminarUsuario />} />}
    </Routes>
  );
};

export default UserManager;
